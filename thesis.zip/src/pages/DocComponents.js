import {useState, useRef} from 'react'
import {Link} from 'react-router-dom'
import DocComponents from '../features/documentation/DocComponents'

function ExternalPage(){


    return(
        <div className="">
            <DocComponents />
        </div>
    )
}

export default ExternalPage